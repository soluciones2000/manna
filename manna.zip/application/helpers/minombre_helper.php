<?php 
	function getNombre(){
		return "<h1>Luis</h1>";
	}
 ?>