<?php 
include_once("conexion.php");
include_once("cabecera.php");
include_once("menu.php");
?>
<div id="cuerpo" align="center">
	<br>
	<br>
	<img align="center" SRC="../recursos/img/manna.png" width=75% height=75%>
</div> 
<?php
include_once("pie.php");
?>
