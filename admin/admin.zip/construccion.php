<?php 
include_once("conexion.php");
include_once("cabecera.php");
$menu="";
include_once("menu.php");
//var_dump($_POST);
?>
<div id="cuerpo" align="center">
	<br>
	<br>
	<h1>EN CONSTRUCCIÓN</h3>
</div> 
<?php
include_once("pie.php");
?>