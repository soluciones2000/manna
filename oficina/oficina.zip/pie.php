            </tr>
         </table>
      </div>
      <div class="footer">Haga clic para recibir soporte técnico por chat: <a href="https://m.me/sgcvzla" target="_blank">Facebook</a> o <a href="https://api.whatsapp.com/send?phone=584144802725" target="_blank">Whatsapp</a>
      </div>
   </body>
</html>