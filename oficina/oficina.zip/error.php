<?php 
echo '<br>';
echo '<br>';
echo '<h2 align="center">Ha ocurrido un error, por favor comuniquese con soporte técnico.</h2>';
echo '<br>';
echo '<form method="post" action="inicio.html">';
	echo '<p align="center"><input type="submit" name="ordenar" value="Volver al inicio"></p>';
echo '</form>';
?>
