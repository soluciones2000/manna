<?php 
	include_once("conexion.php");
	$usuario = true;
	include_once("cabecera.php");
	include_once("menu.php");
	include_once("pie.php");
?>
