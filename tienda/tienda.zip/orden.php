<?php 
include_once("conexion.php");
include_once("cabecera.php");
$ant = "catalogo";
$bnr = false;
$titulo = "Agregar o quitar productos";
$des = "checkout";
include_once("menu.php");
include_once("verificaorden.php");
include_once("pie.php");
?>
