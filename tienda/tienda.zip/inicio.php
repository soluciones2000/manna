<?php 
include_once("conexion.php");
include_once("cabecera.php");
$ant = "pago";
$bnr = true;
$des = "orden";
include_once("menu.php");
include_once("catalogo.php");
include_once("promocion.php");
include_once("pie.php");
?>
