<?php 
include_once("conexion.php");
include_once("cabecera.php");
$ant = "catalogo";
$bnr = false;
$des = "";
include_once("menu.php");
include_once("seguimiento.php");
include_once("pie.php");
?>
