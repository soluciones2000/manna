<?php 
include_once("conexion.php");
include_once("cabecera.php");
$ant = "catalogo";
$bnr = false;
$des = "checkout";
include_once("menu.php");
include_once("registro.php");
include_once("pie.php");
?>
