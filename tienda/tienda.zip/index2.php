<?php 
include_once("conexion.php");
?>
<!DOCTYPE html>


<html>
<head>
	<title>Corporación MANNA C.A. - Tienda virtual - Corporativo 00005</title>
<!--	<link rel="icon" type="image/png" href="psicoexpresate_ico.png" /> -->
</head>
<body>
	<div id="container">
		<div id="cabecera">
			<table border="0" align="center" width="100%" height="10%" style="background-color:#0404B4">
				<tr>
					<td width="20%" align="left" style="padding:0.5%">
						<font face="tahoma" size="4" color="#FFFFFF">
							CORPORATIVO 5<br>
							Luis Antonio Rodríguez Estrada
						</font>
					</td>
					<td align="center">
						<font face="arial" size="6" color="#FFFFFF">
							TIENDA VIRTUAL
						</font>
					</td>
					<td width="20%" align="right" style="padding:0.5%">
						<img SRC="Foto.jpg" width="30%" height="30%">
					</td>
				</tr>
			</table>
		</div>
		<div id="menu">
			<table border="0" align="center" width="100%">
				<tr>
					<td align="right" style="padding-right:2%">
						<font face="arial">
							<a href="#">Ver orden</a>
						</font>
					</td>
				</tr>
			</table>
		</div>
		<div id="promocion1">
			<table border="0" align="center">
				<tr>
					<td width="80%" align="center">
						<img SRC="Frutibal-banner.png" width="40%" height="30%">
					</td>
				</tr>
			</table>
		</div>
		<div id="catalogo">
			<table border="0" align="center" width="100%">
				<tr>
					<td width="25%" align="center">
						<font face="arial">
							Catálogo de productos
						</font>
					</td>
					<td width="25%" align="center">
						<font face="arial">
							<a href="#">Ordenar</a>
						</font>
					</td>
					<td width="25%" align="center">
						<font face="arial">
							<a href="#">Filtrar</a>
						</font>
					</td>
					<td width="25%" align="center">
						<font face="arial">
							<a href="#">Buscar</a>
						</font>
					</td>
				</tr>
				<tr  width="90%" align="center">
					<td width="30%" align="center">
						<img SRC="Frutibal.jpg" width="30%" height="30%">
					</td>
					<td width="30%" align="center">
						<img SRC="crecer.jpg" width="30%" height="30%">
					</td>
					<td width="30%" align="center">
						<img SRC="kat-hogar.jpg" width="30%" height="30%">
					</td>
				</tr>
				<tr  width="90%" align="center">
					<td width="30%" align="center">
						Nombre<br>
						Descripcion corta<br>
						Precio Bs. 999.999,99<br>
						<a href="#">Agregar a la orden</a>
					</td>
					<td width="30%" align="center">
						Nombre<br>
						Descripcion corta<br>
						Precio Bs. 999.999,99<br>
						<a href="#">Agregar a la orden</a>
					</td>
					<td width="30%" align="center">
						Nombre<br>
						Descripcion corta<br>
						Precio Bs. 999.999,99<br>
						<a href="#">Agregar a la orden</a>
					</td>
				</tr>
				<tr  width="90%" align="center">
					<td width="30%" align="center">
						<img SRC="LQ.jpg" width="30%" height="30%">
					</td>
					<td width="30%" align="center">
						<img SRC="Plat-hogar.jpg" width="30%" height="30%">
					</td>
					<td width="30%" align="center">
						<img SRC="teatro.png" width="30%" height="30%">
					</td>
				</tr>
				<tr  width="90%" align="center">
					<td width="30%" align="center">
						Nombre<br>
						Descripcion corta<br>
						Precio Bs. 999.999,99<br>
						<a href="#">Agregar a la orden</a>
					</td>
					<td width="30%" align="center">
						Nombre<br>
						Descripcion corta<br>
						Precio Bs. 999.999,99<br>
						<a href="#">Agregar a la orden</a>
					</td>
					<td width="30%" align="center">
						Nombre<br>
						Descripcion corta<br>
						Precio Bs. 999.999,99<br>
						<a href="#">Agregar a la orden</a>
					</td>
				</tr>
			</table>
		</div>
		<br>
		<div id="paginas">
			<table border="0" align="center" width="100%">
				<tr>
					<td style="padding-left:2%">
						<font face="arial">
							<a href="#"><<</a>
							<a href="#"> 1</a>
							<a href="#"> >></a>
						</font>
					</td>
					<td align="right" style="padding-right:2%">
						<font face="arial">
							<a href="#">Ver orden</a>
						</font>
					</td>
				</tr>
			</table>
		</div>
		<div id="promocion2">
			<table border="0" align="center">
				<tr>
					<td width="80%" align="center">
						<img SRC="Frutibal-banner.png" width="40%" height="30%">
					</td>
				</tr>
			</table>
		</div>
		<div id="pie" top="10%">
			<table border="0" align="center" width="100%">
				<tr>
					<td width="50%" style="padding-left:10%">
						<font face="arial">
							Datos bancarios:<br>
							Corporación Manna C.A.<br>
							Banco Mercantil<br>
							Cuenta corriente<br>
							9999-9999-99-9999999999<br>
						</font>
					</td>
					<td  width="50%" style="padding-left:10%">
						<font face="arial">
							Contacto:<br>
							Teléfono: 0499-999.99.99<br>
							email: xxxxxxxxxxx@yyyyy.zzz<br>
							Dirección corporativa<br>
							Edificio Kerdell<br>
						</font>
					</td>
				</tr>
			</table>
		</div>
	</div>
	<br>
	<br>
	<br>
</body>
</html>
