<?php 
include_once("conexion.php");
include_once("cabecera.php");
$ant = "catalogo";
$bnr = false;
$titulo = "Resumen de la orden para confirmar su envío";
$des = "checkout";
include_once("menu.php");
include_once("resumenorden.php");
include_once("pie.php");
?>
