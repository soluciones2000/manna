		<br>
		<div id="pie" top="10%">
			<table border="0" align="center" width="100%">
				<tr>
<!--
					<td width="50%" style="padding-left:10%">
						<font face="arial">
							Datos bancarios:<br>
							Corporación Manna C.A.<br>
							Banco Mercantil<br>
							Cuenta corriente<br>
							9999-9999-99-9999999999<br>
						</font>
					</td>
					<td  width="50%" style="padding-left:10%">
						<font face="arial">
							Contacto:<br>
							Teléfono: 0499-999.99.99<br>
							email: xxxxxxxxxxx@yyyyy.zzz<br>
							Dirección corporativa<br>
							Edificio Kerdell<br>
						</font>
					</td>
-->
					<td width="100%" align="center">
						<img SRC="banco.jpg" width="40%" height="30%" alt="Agregar a la orden" title="Agregar a la orden">';
					</td>
				</tr>
			</table>
		</div>
	</div>
	<br>
	<br>
	<br>
</body>
</html>
