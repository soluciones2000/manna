<div class="container">
	<div class="center-block">
		<br>
		<br>
		<br>
		<br>
		<br>
		<img class="center-block" SRC="recursos/img/<?php echo $logo ?>" width=75% height=75%>
	</div>
</div>