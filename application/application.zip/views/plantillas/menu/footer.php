<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
    <!--
    <footer class="footer">
        <div class="container" align="right" sytle="position:relative">
            <p class="text-muted">Para soporte técnico comunicarse al (+58) 414-480.2725 o haga click <a href="mailto:info@sgc-consultores.com.ve?Subject=Solicitud%20de%20soporte" target="_top">aqui</a></p>
        </div>
    </footer>
    -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url(); ?>../recursos/js/bootstrap.min.js"></script>
    <!--
    <div class="pie" align="right">
    	<font  face="tahoma" size="1">
    		<strong>
    			Para soporte comunicarse al +58-414-4802725.
    		</strong>
    	</font> 
    </div>
    -->
  </body>
</html>
